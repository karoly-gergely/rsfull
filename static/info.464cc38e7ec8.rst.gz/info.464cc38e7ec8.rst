Django has routes set up for getting the favicon from this folder as it is not part of the webpack rollup it should be removed from gitignore
Items in the public folder are copied over as is